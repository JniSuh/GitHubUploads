<?php
$correct_answers = array('answers'=>array(1,3));

print(json_encode($correct_answers));
?>