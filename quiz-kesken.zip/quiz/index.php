<!DOCTYPE html>
<html>
    <head>
        <title>Programmer Quiz</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="recessDiv">
            <div id="BeginQuiz">
                <h1>10 Questions about programming</h1>
                <br>
                <label>Your nickname:</label> <input type="text" id="nicknameText">
                <br>
                <button class="spacing-10" onclick="startQuiz();">Begin Quiz</button>
                <br>
                <button class="spacing-30">Show Leaderboard</button>
            </div>
            <div id="QuestionsDiv">
                <input type="hidden" name="nickname" id="nickname">
                <!--
                <input type="hidden" class="questionID" value="1">
                <h2>#1</h2> <h3>Which of these is not a programming language?</h3>
                <br><br>
                <input type="radio" class="answer" name="1">Java<br>
                <input type="radio" class="answer" name="1">Kotlin<br>
                <input type="radio" class="answer" name="1">Rust<br>
                <input type="radio" class="answer" name="1">Go<br>
                <hr>
                -->
                <?php
                $mysql = new mysqli('127.0.0.1', 'root', '', 'quizdb');

                if ($mysql->connect_error) {
                    die('SQL connection failed: ' . $mysql->connect_error);
                }

                // get questions from DB
                $questions = $mysql->query('SELECT ID, Question, InputType FROM questions;');

                $question_index = 0;
                if ($questions->num_rows > 0) {
                    while ($question = $questions->fetch_assoc()) {
                        $question_index++;
                        
                        // prints question
                        echo '<input type="hidden" class="questionID" value="'.$question['ID'].'">
                        <h2>#'.$question_index.'</h2> <h3>'.$question['Question'].'</h3>
                        <br><br>';

                        // get possible answers corresponding to question
                        $options = $mysql->query('SELECT Answer, Correct FROM options WHERE QuestionID='.$question['ID'].';');

                        if ($options->num_rows > 0) {
                            // prints possible answers
                            while ($option = $options->fetch_assoc()) {
                                echo '<input type="radio" class="answer" name="'.$question['ID'].'">'.$option['Answer'].'<br>';
                            }
                        }
                    }
                }
                ?>
                <hr>
                <button id="submitQuiz" onclick="sendQuiz();">Submit</button>
            </div>
        </div>
    </body>
    <script>
        const questions = document.getElementsByClassName('questionID');
        const answers = document.getElementsByClassName('answer');
        
        function startQuiz() {
            if (document.getElementById('nicknameText').value.length > 0) {
                document.getElementById('BeginQuiz').style.display = 'none';
                document.getElementById('QuestionsDiv').style.display = 'block';
                document.getElementById('nickname').value = document.getElementById('nicknameText').value;
            } else {
                document.getElementById('nicknameText').style.border = '2px red solid';
            }
        }
        
        function sendQuiz() {
            let QnA_JSON = {results: []};

            for (let q of questions) {
                let i = 0;
                for (let a of answers) {
                    if (q.value == a.name) {
                        i++;
                        if (a.checked) {
                            console.log(i);
                            QnA_JSON.results.push(i);
                        }
                    }
                }
                i = 0;
            }
            if (QnA_JSON.results.length != questions.length) {
                alert('Please answer all questions');
                return;
            }
            console.log(QnA_JSON);
            /*
            {
                results: [
                    1,
                    2,
                    4
                ]
            }
            */

            let xhttp = new XMLHttpRequest();
            xhttp.onload = function() {
                showCorrectAnswers(this.responseText);
            };
            xhttp.open('GET', 'submitQuiz.php?results'+JSON.stringify(QnA_JSON));
            xhttp.send();
        }

        function showCorrectAnswers(response) {
            const correctAnswers = JSON.parse(response);
            /*
            {
                answers: [
                    1,
                    3
                ]
            }
            */

                for (let q in questions) {
                    let i = 0;
                    for (let a of answers) {
                        if (questions[q].value == a.name) {
                            i++;
    
                            if (a.checked) {
                                if (i == correctAnswers.answers[q]) {
                                    a.style.accentColor = 'green';
                                }
                                else {
                                    a.style.accentColor = 'red';
                                }
                            }
                            else if (i == correctAnswers.answers[q]) {
                                a.style.outline = '3px solid lightgreen';
                            }
                        }
                    }
                    i = 0;
                }
        }
    </script>
</html>