<?php
print(shell_exec('whoami'));
print(shell_exec('dir C:\\Users\\h'));
?>